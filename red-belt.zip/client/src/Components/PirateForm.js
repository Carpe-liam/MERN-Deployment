import React, {useState} from 'react'
import axios from 'axios'
import {useHistory} from 'react-router-dom'

const PirateForm = (props) => {
    const [name, setName] = useState('')
    const [image, setImage] = useState('')
    const [treasures, setTreasures] = useState(0)
    const [phrase, setPhrase] = useState('')
    const [position, setPosition] = useState('')
    const [pegLeg, setPegLeg] = useState('no')
    const [eyePatch, setEyePatch] = useState('no')
    const [hookHand, setHookHand] = useState('no')
    const history = useHistory()

    //ARRAY FOR ERRORS
    const [errors, setErrors] = useState([])

    const imgStyle = {
        maxWidth: '300px'
    };

    const formSubmit = e => {
        e.preventDefault()
        const formData = {
            name,
            image,
            treasures,
            phrase,
            position,
            pegLeg,
            eyePatch,
            hookHand
        }
        
        axios.post('http://localhost:8000/pirates/new', formData)
            // SUCCESS POST
            .then(response => {
                console.log(response)
                setErrors([])
                history.push('/pirates')
            })
            // FAIL POST
            .catch(err => {
                const errorResponse  = err.response.data.errors
                console.log(errorResponse)
                const errorArr = []
                // LOOP THROUGH ALL ERRORS AND GET MESSAGES
                for (const key of Object.keys(errorResponse)) {
                    errorArr.push(errorResponse[key].message)
                }
                setErrors(errorArr)
            })
    }

    return(
        <div >
            <form onSubmit={ formSubmit } className="form d-flex justify-content-around">
                <div>
                    <p>
                        <label className="form-label">Pirate Name:</label>
                        <input className="form-control" type="text" onChange={e=> setName(e.target.value)} />
                    </p>
                    <p>
                        <label className="form-label">Image URL:</label>
                        <input className="form-control" type="text" onChange={e=> setImage(e.target.value)} />
                    </p>
                    <p>
                        <label className="form-label"> # of Treasure Chests</label>
                        <input className="form-control" type="number" onChange={e=> setTreasures(e.target.value)}/>
                    </p>
                    <p>
                        <label className="form-label"> Pirate Catch Phrase: </label>
                        <input className="form-control" type="text" onChange={e=> setPhrase(e.target.value)} />
                    </p>
                </div>
                <div>
                    <p>
                        <label className="form-label">Crew Position:</label>
                        <select onChange={e=> setPosition(e.target.value)}>
                            <option value='Captain'>Captain</option>
                            <option value='First Mate'>First Mate</option>
                            <option value='Quarter Master'>Quarter Master</option>
                            <option value='Boatswain'>Boatswain</option>
                            <option value='Powder Monkey'>Powder Monkey</option>
                        </select>
                    </p>
                    <p>
                        <input type="checkbox" checked="checked" onChange={e=> setPegLeg(e.target.value)} /> <label className="ms-2">Peg Leg</label>
                    </p>
                    <p>
                        <input type="checkbox" checked="checked" onChange={e=> setEyePatch(e.target.value)} /> <label className="ms-2">Eye Patch</label>
                    </p>
                    <p>
                        <input type="checkbox" checked="checked" onChange={e=> setHookHand(e.target.value)} /> <label className="ms-2">Hook Hand</label>
                    </p>
                    

                    <input className="btn bg-blue-500 hover:bg-blue-800 mt-4" type="submit" value="Add Pirate" />
                </div>
            </form>
            {errors.map((err, index) => <p key={index} className="text-light">**{err}</p>)}
        </div>
    )
}

export default PirateForm